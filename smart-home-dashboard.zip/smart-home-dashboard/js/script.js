const roomSelect = document.getElementById("roomSelect");
const roomTitle = document.getElementById("roomTitle");
const viewMessage = document.getElementById("viewMessage");
const humidityValue = document.getElementById("humidityValue");
const roomMiniTemp = document.getElementById("roomMiniTemp");
const thermoTitle = document.getElementById("thermoTitle");
const tempValue = document.getElementById("temperatureValue");
const increaseTemp = document.getElementById("increaseTemp");
const decreaseTemp = document.getElementById("decreaseTemp");
const searchInput = document.getElementById("searchInput");
const deviceFilter = document.getElementById("deviceFilter");
const nextDeviceFilter = document.getElementById("nextDeviceFilter");
const powerPeriod = document.getElementById("powerPeriod");
const nextPowerPeriod = document.getElementById("nextPowerPeriod");
const spendingValue = document.getElementById("spendingValue");
const profileMenuButton = document.getElementById("profileMenuButton");
const profileDropdown = document.getElementById("profileDropdown");
const profileName = document.getElementById("profileName");
const noDeviceResult = document.getElementById("noDeviceResult");
const settingsButton = document.getElementById("settingsButton");
const notificationsButton = document.getElementById("notificationsButton");
const settingsPanel = document.getElementById("settingsPanel");
const notificationsPanel = document.getElementById("notificationsPanel");
const notificationBadge = document.getElementById("notificationBadge");
const markReadButton = document.getElementById("markReadButton");
const darkModeToggle = document.getElementById("darkModeToggle");
const autoSaveToggle = document.getElementById("autoSaveToggle");
const energySaverToggle = document.getElementById("energySaverToggle");

const roomData = {
  "Living Room": {
    humidity: 35,
    temperature: 25,
    miniTemp: 15,
    devices: [
      { name: "Refrigerator", icon: "▯", on: true },
      { name: "Temperature", icon: "ϟ", on: true },
      { name: "Air Conditioner", icon: "▤", on: false },
      { name: "Lights", icon: "☼", on: false }
    ],
    sideDevices: [
      { name: "Refrigerator", icon: "▯", on: true, color: "purple" },
      { name: "Router", icon: "♨", on: true, color: "yellow" },
      { name: "Music System", icon: "◎", on: true, color: "orange" },
      { name: "Lamps", icon: "♟", on: true, color: "cyan" }
    ]
  },
  "Bedroom": {
    humidity: 42,
    temperature: 22,
    miniTemp: 18,
    devices: [
      { name: "Bed Lamp", icon: "♟", on: true },
      { name: "Fan", icon: "✦", on: false },
      { name: "Air Conditioner", icon: "▤", on: true },
      { name: "Curtains", icon: "▥", on: false }
    ],
    sideDevices: [
      { name: "Bed Lamp", icon: "♟", on: true, color: "purple" },
      { name: "Fan", icon: "✦", on: false, color: "yellow" },
      { name: "AC", icon: "▤", on: true, color: "orange" },
      { name: "Curtains", icon: "▥", on: false, color: "cyan" }
    ]
  },
  "Kitchen": {
    humidity: 30,
    temperature: 24,
    miniTemp: 20,
    devices: [
      { name: "Oven", icon: "▣", on: false },
      { name: "Fridge", icon: "▯", on: true },
      { name: "Coffee Maker", icon: "☕", on: true },
      { name: "Kitchen Lights", icon: "☼", on: true }
    ],
    sideDevices: [
      { name: "Oven", icon: "▣", on: false, color: "purple" },
      { name: "Fridge", icon: "▯", on: true, color: "yellow" },
      { name: "Coffee Maker", icon: "☕", on: true, color: "orange" },
      { name: "Lights", icon: "☼", on: true, color: "cyan" }
    ]
  }
};

const chartData = {
  week: { spending: 41, bars: [35, 48, 30, 55, 42, 65, 58, 46], label: "Week" },
  month: { spending: 73, bars: [60, 72, 105, 83, 102, 128, 118, 96], label: "Month" },
  year: { spending: 88, bars: [75, 92, 115, 98, 130, 145, 122, 138], label: "Year" }
};

let currentRoom = "Living Room";
let temperature = roomData[currentRoom].temperature;

function showToast(message) {
  let toast = document.querySelector(".action-toast");
  if (!toast) {
    toast = document.createElement("div");
    toast.className = "action-toast";
    document.body.appendChild(toast);
  }
  toast.textContent = message;
  toast.classList.add("show");
  setTimeout(() => toast.classList.remove("show"), 1800);
}

function getDeviceCards() {
  return document.querySelectorAll(".device-card");
}

function getMiniDevices() {
  return document.querySelectorAll(".mini-device");
}

function setToggle(toggle, isOn) {
  toggle.classList.toggle("on", isOn);
}

function applySwitchState(card, isOn) {
  // Functional state: ON/OFF controls the card color
  card.classList.toggle("on", isOn);
  card.classList.toggle("off", !isOn);
  card.classList.toggle("switched-off", !isOn);

  const statusText = card.querySelector(".device-top span:first-child");
  if (statusText) statusText.textContent = isOn ? "ON" : "OFF";

  const toggle = card.querySelector(".toggle");
  if (toggle) setToggle(toggle, isOn);
}

function renderRoom(roomName) {
  currentRoom = roomName;
  const data = roomData[roomName];
  temperature = data.temperature;

  roomTitle.textContent = `Scarlett’s ${roomName}`;
  viewMessage.textContent = `Dashboard overview for ${roomName}`;
  humidityValue.textContent = `💧 ${data.humidity}%`;
  roomMiniTemp.textContent = `♨ ${data.miniTemp}°C`;
  thermoTitle.textContent = `ϟ ${roomName} Temperature`;
  tempValue.textContent = `${temperature}°C`;

  getDeviceCards().forEach((card, index) => {
    const device = data.devices[index];
    if (!device) return;

    card.querySelector(".device-icon").textContent = device.icon;
    card.querySelector(".device-title").textContent = device.name;
    applySwitchState(card, device.on);
    card.classList.remove("hidden-by-filter", "search-match");
  });

  getMiniDevices().forEach((card, index) => {
    const device = data.sideDevices[index];
    if (!device) return;

    card.className = `mini-device ${device.color}`;
    card.querySelector("span").textContent = device.icon;
    card.querySelector("strong").textContent = device.name;

    const toggle = card.querySelector(".toggle");
    setToggle(toggle, device.on);
    card.classList.toggle("switched-off", !device.on);
  });

  const cards = getDeviceCards();
  cards.forEach((item) => item.classList.remove("selected"));
  const firstOnCard = Array.from(cards).find((card) => card.classList.contains("on"));
  if (firstOnCard) {
    firstOnCard.classList.add("selected");
  }

  applyAllFilters();
}

function applyDeviceFilter() {
  const filter = deviceFilter.value;

  getMiniDevices().forEach((card) => {
    const isOn = card.querySelector(".toggle").classList.contains("on");
    const shouldShow =
      filter === "all" ||
      (filter === "on" && isOn) ||
      (filter === "off" && !isOn);

    card.classList.toggle("hidden-by-filter", !shouldShow);
  });
}

function applySearch() {
  const query = searchInput.value.trim().toLowerCase();
  let visibleMainCards = 0;

  getDeviceCards().forEach((card) => {
    const title = card.querySelector(".device-title").textContent.toLowerCase();
    const matchSearch = !query || title.includes(query) || currentRoom.toLowerCase().includes(query);

    card.classList.toggle("hidden-by-filter", !matchSearch);
    card.classList.toggle("search-match", !!query && matchSearch);

    if (matchSearch) visibleMainCards += 1;
  });

  getMiniDevices().forEach((card) => {
    const title = card.querySelector("strong").textContent.toLowerCase();
    const matchSearch = !query || title.includes(query) || currentRoom.toLowerCase().includes(query);
    card.classList.toggle("search-match", !!query && matchSearch);
  });

  noDeviceResult.classList.toggle("show", visibleMainCards === 0);
}

function applyAllFilters() {
  applyDeviceFilter();
  applySearch();
}

function updatePowerChart(period) {
  const data = chartData[period];
  spendingValue.textContent = `${data.spending}% Spending`;

  const bars = document.querySelectorAll(".chart-css .bar");
  bars.forEach((bar, index) => {
    bar.style.height = `${data.bars[index]}px`;
    bar.classList.toggle("active", index === 5);
  });

  viewMessage.textContent = `Power chart changed to ${data.label} view for ${currentRoom}`;
  showToast(`Power Consumed changed to ${data.label}`);
}

function cycleSelect(selectElement) {
  const nextIndex = (selectElement.selectedIndex + 1) % selectElement.options.length;
  selectElement.selectedIndex = nextIndex;
  selectElement.dispatchEvent(new Event("change"));
}

function openPanel(panel) {
  panel.classList.add("open");
  panel.setAttribute("aria-hidden", "false");
}

function closePanel(panel) {
  panel.classList.remove("open");
  panel.setAttribute("aria-hidden", "true");
}

// Device card active selection
getDeviceCards().forEach((card) => {
  card.addEventListener("click", () => {
    getDeviceCards().forEach((item) => item.classList.remove("selected"));
    card.classList.add("selected");
  });
});

// Room dropdown action
roomSelect.addEventListener("change", (event) => {
  renderRoom(event.target.value);
  showToast(`Room changed to ${event.target.value}`);
});

// My Devices dropdown action
deviceFilter.addEventListener("change", () => {
  applyDeviceFilter();
  showToast(`My Devices filtered: ${deviceFilter.options[deviceFilter.selectedIndex].text}`);
});

nextDeviceFilter.addEventListener("click", () => {
  cycleSelect(deviceFilter);
});

// Power consumed dropdown action
powerPeriod.addEventListener("change", () => {
  updatePowerChart(powerPeriod.value);
});

nextPowerPeriod.addEventListener("click", () => {
  cycleSelect(powerPeriod);
});

// Search action
searchInput.addEventListener("input", () => {
  applyAllFilters();
});

// Profile avatar dropdown
profileMenuButton.addEventListener("click", (event) => {
  event.stopPropagation();
  profileDropdown.classList.toggle("open");
});

profileMenuButton.addEventListener("keydown", (event) => {
  if (event.key === "Enter") {
    profileDropdown.classList.toggle("open");
  }
});

profileDropdown.querySelectorAll("button").forEach((button) => {
  button.addEventListener("click", (event) => {
    event.stopPropagation();
    const label = button.textContent;
    viewMessage.textContent = `${label} clicked for ${profileName.textContent}`;
    profileDropdown.classList.remove("open");
    showToast(`${label} selected`);
  });
});

document.addEventListener("click", () => {
  profileDropdown.classList.remove("open");
});

// Toggle ON/OFF switch reaction
document.addEventListener("click", (event) => {
  const toggle = event.target.closest(".toggle");
  if (!toggle) return;

  event.stopPropagation();

  toggle.classList.toggle("on");
  const isOn = toggle.classList.contains("on");
  const parentCard = toggle.closest(".device-card, .mini-device, .thermostat-card, .setting-row");

  if (parentCard) {
    if (parentCard.classList.contains("device-card")) {
      applySwitchState(parentCard, isOn);
    } else {
      parentCard.classList.toggle("switched-off", !isOn);

      const statusText = parentCard.querySelector(".device-top span:first-child");
      if (statusText) statusText.textContent = isOn ? "ON" : "OFF";
    }
  }

  applyAllFilters();
  showToast(isOn ? "Switched ON" : "Switched OFF");
});

// Temperature controls
increaseTemp.addEventListener("click", () => {
  const thermostatOff = document.querySelector(".thermostat-card").classList.contains("switched-off");
  if (!thermostatOff && temperature < 30) {
    temperature += 1;
    tempValue.textContent = `${temperature}°C`;
  }
});

decreaseTemp.addEventListener("click", () => {
  const thermostatOff = document.querySelector(".thermostat-card").classList.contains("switched-off");
  if (!thermostatOff && temperature > 5) {
    temperature -= 1;
    tempValue.textContent = `${temperature}°C`;
  }
});

// Settings and notifications
settingsButton.addEventListener("click", () => {
  openPanel(settingsPanel);
  showToast("Settings opened");
});

notificationsButton.addEventListener("click", () => {
  openPanel(notificationsPanel);
  showToast("Notifications opened");
});

document.querySelectorAll(".close-panel").forEach((button) => {
  button.addEventListener("click", () => {
    const panelId = button.dataset.closePanel;
    const panel = document.getElementById(panelId);
    closePanel(panel);
  });
});

[settingsPanel, notificationsPanel].forEach((panel) => {
  panel.addEventListener("click", (event) => {
    if (event.target === panel) {
      closePanel(panel);
    }
  });
});

darkModeToggle.addEventListener("click", (event) => {
  event.stopPropagation();
  darkModeToggle.classList.toggle("on");
  document.body.classList.toggle("dark-demo", darkModeToggle.classList.contains("on"));
  showToast(darkModeToggle.classList.contains("on") ? "Dark mode ON" : "Dark mode OFF");
});

autoSaveToggle.addEventListener("click", (event) => {
  event.stopPropagation();
  autoSaveToggle.classList.toggle("on");
  showToast(autoSaveToggle.classList.contains("on") ? "Auto Save ON" : "Auto Save OFF");
});

energySaverToggle.addEventListener("click", (event) => {
  event.stopPropagation();
  energySaverToggle.classList.toggle("on");
  showToast(energySaverToggle.classList.contains("on") ? "Energy Saver ON" : "Energy Saver OFF");
});

markReadButton.addEventListener("click", () => {
  document.querySelectorAll(".notification-item").forEach((item) => {
    item.classList.remove("unread");
    item.classList.add("read");
  });
  notificationBadge.textContent = "0";
  notificationBadge.style.display = "none";
  viewMessage.textContent = "All notifications marked as read";
  showToast("All notifications marked as read");
});

// Initial render
renderRoom(currentRoom);
updatePowerChart("month");
