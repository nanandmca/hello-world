const menuToggle = document.querySelector(".menu-toggle");
const navLinks = document.querySelector(".nav-links");
const contactForm = document.querySelector("#contact-form");
const faqButtons = document.querySelectorAll(".faq-item button");
const backToTopButton = document.querySelector(".back-to-top");

// Mobile navigation toggle.
menuToggle.addEventListener("click", () => {
    const isOpen = navLinks.classList.toggle("open");
    menuToggle.setAttribute("aria-expanded", isOpen);
});

// Smooth scroll and close the mobile menu after choosing a link.
document.querySelectorAll(".nav-links a").forEach((link) => {
    link.addEventListener("click", (event) => {
        const target = document.querySelector(link.getAttribute("href"));

        if (target) {
            event.preventDefault();
            target.scrollIntoView({ behavior: "smooth" });
        }

        navLinks.classList.remove("open");
        menuToggle.setAttribute("aria-expanded", "false");
    });
});

// Friendly school-project form response.
contactForm.addEventListener("submit", (event) => {
    event.preventDefault();
    alert("Thank you for contacting Red Fox Nature Cafe!");
    contactForm.reset();
});

// Simple FAQ accordion.
faqButtons.forEach((button) => {
    button.addEventListener("click", () => {
        const faqItem = button.parentElement;
        const isOpen = faqItem.classList.toggle("active");
        button.setAttribute("aria-expanded", isOpen);
    });
});

window.addEventListener("scroll", () => {
    backToTopButton.classList.toggle("visible", window.scrollY > 500);
});

backToTopButton.addEventListener("click", () => {
    window.scrollTo({
        top: 0,
        behavior: "smooth"
    });
});
