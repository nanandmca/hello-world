import speech_recognition as sr
import sys

r = sr.Recognizer()

def transcribe_audio_en_in(audio_file_path):
    """Transcribes audio from a file into text using Indian English (en-IN).

    Args:
        audio_file_path (str): Path to the audio file.

    Returns:
        str: The transcribed text, or None if there are errors.
    """

    try:
        with sr.AudioFile(audio_file_path) as source:
            audio_text = r.record(source)
            text = r.recognize_google(audio_text, language='en-IN')
            return text

    except FileNotFoundError:
        print(f"File not found: {audio_file_path}")
        return None

    except sr.UnknownValueError:
        print("Sorry, could not understand audio.")
        return None

    except sr.RequestError as e:
        print("Could not request results from speech recognition service; {e}")
        return None

if __name__ == "__main__":
    if len(sys.argv) != 2:
        print("Usage: python AudioToText.py <path_to_audio_file>")
        sys.exit(1)

    audio_file_path = sys.argv[1]
    text = transcribe_audio_en_in(audio_file_path)

    if text:
        print("Transcribed text:")
        print(text)
    else:
        print("An error occurred during transcription.")
