const express = require('express');
const { createProxyMiddleware } = require('http-proxy-middleware');

const app = express();

// Proxy setup
app.use('/v1/api/auth/public-keys', createProxyMiddleware({
    target: 'http://localhost:3001',
    changeOrigin: true, // Ensures the origin header is rewritten
    pathRewrite: {
        '^/v1/api/auth': '/auth', // Optional: Rewrite the path before forwarding
    },
    onProxyReq: (proxyReq, req, res) => {
        console.log(`Proxying request to: ${proxyReq.href}`);
    },
    onError: (err, req, res) => {
        console.error('Error proxying request:', err.message);
        res.status(502).json({ message: 'Bad Gateway: Authentication Service is down' });
    },
    onProxyRes: (proxyRes, req, res) => {
        console.log(`Received response: ${proxyRes.statusCode}`);
    }
}));

app.listen(3000, () => {
    console.log('API Gateway running on port 3000');
});
