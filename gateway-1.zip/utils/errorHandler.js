function errorHandler(err, req, res, next) {
  console.error("Unexpected Error:", err);
  res.status(500).json({ message: "Internal Server Error" });
}

module.exports = errorHandler;
