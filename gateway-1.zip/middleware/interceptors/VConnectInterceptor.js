const BaseInterceptor = require("@interceptors/BaseInterceptor");

class VConnectInterceptor extends BaseInterceptor {
  // Override requestInterceptor for /api/vconnect route-specific logic
  requestInterceptor(req, res, next) {
    super.requestInterceptor(req, res, next); // Call base logic

    // Add any specific logic for /api/vconnect
    if (req.path.includes("healthcheck")) {
      console.log("VConnect Interceptor: Specific Logic for Healthcheck");
    }

    next(); // Continue to the next middleware
  }

  // Override responseInterceptor for /api/vconnect route-specific logic
  responseInterceptor(req, res, next) {
    super.responseInterceptor(req, res, next); // Call base logic

    // Add any specific logic for /api/vconnect
    res.setHeader("X-VConnect-Specific-Header", "VConnectService");

    next(); // Continue to the next middleware
  }
}

module.exports = VConnectInterceptor;
