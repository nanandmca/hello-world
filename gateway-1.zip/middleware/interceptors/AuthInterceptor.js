const BaseInterceptor = require("@interceptors/BaseInterceptor");

class AuthInterceptor extends BaseInterceptor {
  // Override requestInterceptor for /api/auth route-specific logic
  requestInterceptor(req, res, next) {
    console.log("Auth Interceptor: requestInterceptor");
    super.requestInterceptor(req, res, next); // Call base logic

    if (req.path.includes("login")) {
      console.log("Auth Interceptor: Specific Logic for Login");
    }
    console.log("Auth Interceptor: requestInterceptor Before Next");
    next();
  }

  // Override responseInterceptor for /api/auth route-specific logic
  responseInterceptor(req, res, next) {
    console.log("Auth Interceptor: responseInterceptor");
    super.responseInterceptor(req, res, next); // Call base logic
    res.setHeader("X-Auth-Specific-Header", "AuthService");
    console.log("Auth Interceptor: responseInterceptor Before Next");
    next();
  }
}

module.exports = AuthInterceptor;
