class BaseInterceptor {
  // Method to check if the value is defined before setting a header
  setHeaderIfDefined(res, headerName, value) {
    if (value !== undefined && value !== null) {
      res.setHeader(headerName, value);
    } else {
      console.warn(
        `Header "${headerName}" not set because the value is undefined or null.`
      );
    }
  }

  // This will be called on the request before reaching the route handler
  requestInterceptor(req, res, next) {
    console.log("Base Request Interceptor Logic");
    res.setHeader(
      "X-Base-Request-Processed-Time",
      `${new Date().toISOString()}`
    );
    //next();
  }

  // This will be called on the response after the route handler
  responseInterceptor(req, res, next) {
    console.log("Base Response Interceptor Logic");
    res.setHeader("X-Base-Response-Time", `${Date.now() - req.startTime} ms`);
    //next();
  }
}

module.exports = BaseInterceptor;
