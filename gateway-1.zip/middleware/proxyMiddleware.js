const authenticationServiceProxy = require("@services/authenticationService");
const vConnectEmergencyServiceProxy = require("@services/vConnectEmergencyService");

// Proxy Middleware for User Service
function authenticationServiceProxyMiddleware(req, res, next) {
  authenticationServiceProxy(req, res, next);
}

// Proxy Middleware for Product Service
function vConnectEmergencyServiceProxyMiddleware(req, res, next) {
  vConnectEmergencyServiceProxy(req, res, next);
}

module.exports = {
  authenticationServiceProxyMiddleware,
  vConnectEmergencyServiceProxyMiddleware,
};
