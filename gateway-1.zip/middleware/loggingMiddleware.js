const logger = require("@config/accesslogger");

// Logging middleware for HTTP requests
function loggingMiddleware(req, res, next) {
  logger(req, res, next);
}

module.exports = loggingMiddleware;
