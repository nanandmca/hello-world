const express = require('express');

//require('module-alias/register');

//const authenticationServiceProxy = require("@services/authenticationService");
const { createProxyMiddleware } = require("http-proxy-middleware");


// Setup Express App
const app = express();
const PORT = process.env.PORT || 3000;

/*
// Log when a request is made to the public-keys endpoint
app.use('/v1/api/auth/public-keys', (req, res, next) => {
    console.log(`Request to /v1/api/auth/public-keys received: ${req.method} ${req.url}`);
    next();  // Proceed to the next middleware (the proxy)
});

// Test middleware to check if proxy middleware is being invoked
app.use('/v1/api/auth/public-keys', (req, res, next) => {
    console.log('Proxy Middleware Triggered');
    next();  // Call the next middleware
});

console.log('authenticationServiceProxy -> ', authenticationServiceProxy);
app.use('/v1/api/auth/public-keys', authenticationServiceProxy);  // Proxy the request
*/

// For debugging purposes, just forward to the backend without pathRewrite or other logic
app.use('/v2/api/auth/public-keys', createProxyMiddleware({
    target: 'http://localhost:3001',
    changeOrigin: true,
    logLevel: 'debug',  // Enable debug logging
    onProxyReq: (proxyReq, req, res) => {
        console.log(`Proxying request to: ${proxyReq.href}`); // Log the URL being forwarded
    },
    onError: (err, req, res) => {
        console.error(`Error in proxying request: ${err.message}`);
        res
            .status(502)
            .json({ message: "Bad Gateway: authentication Service is down" });
    },
    onProxyRes: (proxyRes, req, res) => {
        // Log the response status code from the target
        console.log(`Received ${proxyRes.statusCode} from ${req.url}`);
    },
}));


// Start the API Gateway server
app.listen(PORT, () => {
    console.log(`API Gateway running on port ${PORT}`);
    //gwlogger.info(`API Gateway running on port ${PORT}`);
});
