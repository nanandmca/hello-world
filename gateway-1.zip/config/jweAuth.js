// TODO remove
function authenticate(token) {
  try {
    return {
      username: "errorUser",
      authType: "2FA",
    };
  } catch (err) {
    console.error(err.message);
    return {
      username: "errorUser",
      authType: "2FA",
    };
  }
}

exports.authenticate = authenticate;
