const morgan = require("morgan");

const winston = require("winston");
require("winston-daily-rotate-file");
const path = require("path");
//const logDirectory = process.env.LOG_DIRECTORY || '/tmp';
const logDirectory =
  process.env.LOG_DIRECTORY ||
  (process.platform === "win32"
    ? "C:\\MyFiles\\MyWork\\vConnect\\winze-gateway\\logs"
    : "/tmp");

// Create a transport for daily log rotation
const dailyRotateAccessLogs = new winston.transports.DailyRotateFile({
  filename: path.join(logDirectory, "access/access-%DATE%.log"),
  datePattern: "YYYY-MM-DD",
  zippedArchive: true, // Optional: Compress old logs
  maxSize: "20m", // Optional: Max log file size before rotation
  maxFiles: "30d", // Optional: Keep logs for 30 days
});

// Define the logger
const accessLogsLogger = winston.createLogger({
  level: "info",
  transports: [
    dailyRotateAccessLogs, // Write to daily rotated file
    new winston.transports.Console({ format: winston.format.simple() }), // Optional: Log to the console
  ],
});

// Logging setup for HTTP requests (combined format)
//const logger = morgan('combined');
const logger = morgan("combined", {
  stream: { write: (message) => accessLogsLogger.info(message.trim()) },
});

module.exports = logger;
