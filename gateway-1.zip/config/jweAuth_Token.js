const { generateKeyPairSync } = require("crypto");
const jose = require("jose");

// Step 1: Generate RSA Key Pair
const { privateKey, publicKey } = generateKeyPairSync("rsa", {
  modulusLength: 2048, // RSA key size
  publicKeyEncoding: {
    type: "spki", // Use "spki" for public key encoding
    format: "pem", // PEM format for public key
  },
  privateKeyEncoding: {
    type: "pkcs8", // Use "pkcs8" for private key encoding
    format: "pem", // PEM format for private key
  },
});

console.log("Private Key:", privateKey);
console.log("Public Key:", publicKey);

// Function to simulate encrypting a message and returning a JWE
async function encryptMessage(publicKeyPem) {
  try {
    // Import the public key using importSPKI for public keys (PEM to JWK)
    const publicKeyJwk = await jose.importSPKI(publicKeyPem, "RSA-OAEP");

    const payload = "This is a secret message";

    // Encrypt the message with the public key (RSA-OAEP, A256GCM)
    const encryptedJWE = await new jose.EncryptJWT({ msg: payload })
      .setProtectedHeader({ alg: "RSA-OAEP", enc: "A256GCM" })
      .encrypt(publicKeyJwk);

    console.log("Encrypted JWE:", encryptedJWE);
    return encryptedJWE;
  } catch (error) {
    console.error("Error encrypting message:", error);
  }
}

// Step 2: Decrypt the JWE token using the private key
async function decryptMessage(privateKeyPem, encryptedJWE) {
  try {
    // Import the private key using importPKCS8 for private keys (PEM to JWK)
    const privateKeyJwk = await jose.importPKCS8(privateKeyPem, "RSA-OAEP");

    // Decrypt the JWE token using the private key
    const { payload } = await jose.jwtDecrypt(encryptedJWE, privateKeyJwk);

    console.log("Decrypted Message:", payload.toString());
    return payload.toString();
  } catch (error) {
    console.error("Error decrypting message:", error);
  }
}

// Step 3: Authenticate method
async function authenticate(jweToken) {
  try {
    // Decrypt the JWE token using the private key
    const decryptedToken = await decryptMessage(privateKey, jweToken);

    // Return the decrypted token and public key
    return {
      decryptedToken,
      publicKey,
    };
  } catch (error) {
    console.error("Error during authentication:", error);
    throw new Error("Authentication failed");
  }
}

// Example usage
(async () => {
  // Encrypt a message with the public key
  const encryptedJWE = await encryptMessage(publicKey);

  // Authenticate using the JWE token
  const result = await authenticate(encryptedJWE);

  console.log("Authenticated Result:", result);
})();
