module.exports = {
  unsecuredEndpoints: [{ path: "/healthcheck", method: ["GET"] }],
  securedEndpoints: [
    // branches
    { path: "/branches", method: ["GET"], authType: "1FA" },
    { path: "/branches", method: ["POST"], authType: "1FA" },
    { path: "/branches/:id", method: ["GET"], authType: "1FA" },
    { path: "/branches/:id", method: ["PUT"], authType: "1FA" },
    { path: "/branches/:id", method: ["DELETE"], authType: "1FA" },

    // Codes
    { path: "/codes", method: ["GET"], authType: "1FA" },
    { path: "/codes", method: ["POST"], authType: "1FA" },
    { path: "/codes/:id", method: ["GET"], authType: "1FA" },
    { path: "/codes/:id", method: ["PUT"], authType: "1FA" },
    { path: "/codes/:id", method: ["DELETE"], authType: "1FA" },
  ],
};
