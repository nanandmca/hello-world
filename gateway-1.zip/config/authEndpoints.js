module.exports = {
  unsecuredEndpoints: [
    { path: "/public-keys", method: ["GET"] },
    { path: "/login", method: ["POST"] },
    { path: "/register", method: ["POST"] },
    { path: "/forgot-password", method: ["POST"] },
  ],
  securedEndpoints: [
    { path: "/customers", method: ["GET"], authType: "1FA" }, // Get all customers
    { path: "/customers/:id", method: ["GET"], authType: "1FA" }, // Get customer by ID
    { path: "/customers/create", method: ["POST"], authType: "1FA" }, // Create a new customer
    { path: "/customers/:id", method: ["PUT"], authType: "1FA" }, // Update an existing customer
    { path: "/customers/:id", method: ["DELETE"], authType: "1FA" }, // Delete a customer

    { path: "/users", method: ["GET"], authType: "1FA" },
    { path: "/userInfo", method: ["GET"], authType: "1FA" },
    { path: "/changePassword", method: ["POST"], authType: "1FA" },
    { path: "/verify2FA", method: ["POST"], authType: "2FA" },
    { path: "/changeSecuritySettings", method: ["PUT"], authType: "2FA" },
  ],
};
