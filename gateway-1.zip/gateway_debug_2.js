const express = require('express');
const httpProxy = require('http-proxy');

const app = express();

// Create a proxy server
const proxy = httpProxy.createProxyServer({});


// Custom createProxyMiddleware function
function createCustomProxyMiddleware(options) {
    const proxy = httpProxy.createProxyServer({});

    return (req, res, next) => {
        // Default options
        const {
            target,
            changeOrigin = true,
            pathRewrite = {},
            onProxyReq = null,
            onError = null,
            onProxyRes = null,
            logLevel = 'debug'
        } = options;

        // Path Rewrite: Update the request path based on the `pathRewrite` rules
        // Determine the target URL
        let requestPath = req.originalUrl;  // Original request path
        console.log(`Original Request Path: ${requestPath}`);

        for (const [pattern, replacement] of Object.entries(pathRewrite)) {
            const regex = new RegExp(pattern);
            if (regex.test(requestPath)) {
                requestPath = requestPath.replace(regex, replacement);
                if (logLevel === 'debug') {
                    console.log(`Path rewritten: ${req.url} -> ${requestPath}`);
                }
                break;
            }
        }

        // Ensure the rewritten path is valid
        if (!requestPath) {
            console.error('Rewritten path is empty!');
            return res.status(400).json({ message: 'Invalid rewritten path' });
        }

        // Create the full target URL
        const targetUrl = target + requestPath;

        // Log the final proxy URL
        console.log(`Proxying request to: ${targetUrl}`);

        // Set the target URL (handling the change of origin if necessary)
        const proxyOptions = {
            target,
            changeOrigin,
            path: requestPath,
            logLevel,
        };

        // Handling onProxyReq callback (if provided)
        if (onProxyReq) {
            onProxyReq(proxy, req, res);
        }

        // Proxy the request to the target
        proxy.web(req, res, { target: targetUrl }, (err) => {
            // Handle proxy errors (onError callback)
            if (onError) {
                onError(err, req, res);
            } else {
                console.error(`Proxy error: ${err.message}`);
                res.status(502).json({ message: 'Bad Gateway: Authentication Service is down' });
            }
        });

        // Handling onProxyRes callback (if provided)
        if (onProxyRes) {
            proxy.on('proxyRes', (proxyRes, req, res) => {
                onProxyRes(proxyRes, req, res);
            });
        }
    };
}


// Set up a route to proxy requests
app.use('/v1/api/auth/public-keys', (req, res) => {
    console.log(`Proxying request to: http://localhost:3001 -> ${req.originalUrl}`);

    // Rewrite the request URL to match the target server's path structure
    const targetUrl = 'http://localhost:3001';
    const proxyPath = '/auth/public-keys';  // This is the correct path on the target server

    // Combine the target URL with the path
    const newUrl = targetUrl + proxyPath;

    console.log(`Proxying request to: ${newUrl} ${req.originalUrl}`);

    proxy.web(req, res, { target: newUrl }, (err) => {
        console.error('Error proxying request:', err.message);
        res.status(502).json({ message: 'Bad Gateway: Authentication Service is down' });
    });
});

// Example of using the custom middleware with Express
const customProxy = createCustomProxyMiddleware({
    target: 'http://localhost:3001', // Target authentication service
    changeOrigin: true,  // Change the origin of the request
    pathRewrite: {
        '^/v2/api/auth': '/auth',  // Rewrite /v2/api/auth -> /auth on the target server
    },
    logLevel: 'debug',  // Enable debug logging
    onProxyReq: (proxyReq, req, res) => {
        console.log(`onProxyReq -> Proxying request to: ${proxyReq.href}`);  // Log the target URL
    },
    onError: (err, req, res) => {
        console.error(`onError -> Error while proxying request: ${err.message}`);
        res.status(502).json({ message: 'Bad Gateway: Authentication Service is down' });
    },
    onProxyRes: (proxyRes, req, res) => {
        console.log(`onProxyRes -> Response received with status: ${proxyRes.statusCode}`);
    },
});

// Use the proxy middleware in your Express app
app.use('/v2/api/auth/public-keys', customProxy);

app.listen(3000, () => {
    console.log('API Gateway running on port 3000');
});
