const { createProxyMiddleware } = require("http-proxy-middleware");

const authenticationServiceUrls = [
  "http://localhost:3001", // authentication service instance 1
  // 'http://localhost:3002', // authentication service instance 2 (for load balancing) changes
];

let authenticationServiceIndex = 0;

function getNextAuthenticationService() {
  authenticationServiceIndex =
    (authenticationServiceIndex + 1) % authenticationServiceUrls.length;
  return authenticationServiceUrls[authenticationServiceIndex];
}

const authenticationServiceProxy = createProxyMiddleware({
  target: getNextAuthenticationService(),
  changeOrigin: true,
  /*pathRewrite: {
        '^/api/auth': '/auth', // Strip out /api/auth from the URL before forwarding to the backend
  },*/
  onProxyReq: (proxyReq, req, res) => {
    console.log(`Proxying request to: ${proxyReq.href}`); // Log the URL being forwarded
  },
  onError: (err, req, res) => {
    console.error(`Error in proxying request: ${err.message}`);
    res
      .status(502)
      .json({ message: "Bad Gateway: authentication Service is down" });
  },
  onProxyRes: (proxyRes, req, res) => {
    // Log the response status code from the target
    console.log(`Received ${proxyRes.statusCode} from ${req.url}`);
  },
});

module.exports = authenticationServiceProxy;
