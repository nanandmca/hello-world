const {createProxyMiddleware} = require('http-proxy-middleware');
const vConnectEmergencyServiceUrls = [
    'http://localhost:4001', // vConnectEmergency service instance 1
    'http://localhost:4002', // vConnectEmergency service instance 2 (for load balancing)
];

let vConnectEmergencyServiceIndex = 0;

function getNextVConnectEmergencyService() {
    vConnectEmergencyServiceIndex = (vConnectEmergencyServiceIndex + 1) % vConnectEmergencyServiceUrls.length;
    return vConnectEmergencyServiceUrls[vConnectEmergencyServiceIndex];
}

const vConnectEmergencyServiceProxy = createProxyMiddleware({
    target: getNextVConnectEmergencyService(),
    changeOrigin: true,
    onError: (err, req, res) => {
        console.error(`Error in proxying request: ${err.message}`);
        res.status(502).json({message: 'Bad Gateway: vConnectEmergency Service is down'});
    }
});

module.exports = vConnectEmergencyServiceProxy;

