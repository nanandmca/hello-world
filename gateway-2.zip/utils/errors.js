class ServiceError extends Error {
    constructor(message, statusCode = 502) {
        super(message);
        this.statusCode = statusCode;
        this.name = 'ServiceError';
    }
}

class AuthError extends Error {
    constructor(message) {
        super(message);
        this.statusCode = 401;
        this.name = 'AuthError';
    }
}

class ValidationError extends Error {
    constructor(message) {
        super(message);
        this.statusCode = 400;
        this.name = 'ValidationError';
    }
}

module.exports = { ServiceError, AuthError, ValidationError };
