const { ServiceError, AuthError, ValidationError } = require('@utils/errors');

function errorHandler(err, req, res, next) {
    console.error('Unexpected Error:', err);
    if (err instanceof AuthError) {
        return res.status(err.statusCode).json({ message: err.message });
    }
    if (err instanceof ValidationError) {
        return res.status(err.statusCode).json({ message: err.message });
    }
    if (err instanceof ServiceError) {
        return res.status(err.statusCode).json({ message: err.message });
    }

    // Fallback to generic error
    console.error(err.stack);
    res.status(500).json({ message: 'Internal Server Error' });
}

module.exports = errorHandler;
