const express = require('express');

require('module-alias/register');

const {createProxyMiddleware} = require('http-proxy-middleware');

const {authenticationServiceProxyMiddleware, vConnectEmergencyServiceProxyMiddleware} = require('@middleware/proxyMiddleware');
const loggingMiddleware = require('@middleware/loggingMiddleware');
const authMiddleware = require('@middleware/authorizationMiddleware');
const rateLimiter = require('@config/rateLimiter');
const errorHandler = require('@utils/errorHandler');

const gwlogger = require('@config/logger');

// Import route-specific interceptors
const AuthInterceptor = require('@interceptors/AuthInterceptor');
const VConnectInterceptor = require('@interceptors/VConnectInterceptor');

// Import the service-specific configurations
const authEndpoints = require('@config/authEndpoints');
const vConnectEndpoints = require('@config/vConnectEndpoints');

// Setup Express App
const app = express();
const PORT = process.env.PORT || 3000;

// Instantiate interceptors
const authInterceptor = new AuthInterceptor();
const vConnectInterceptor = new VConnectInterceptor();

// Helper function to dynamically apply middleware, interceptors, and proxy middleware
function applyProxyRoute(path, authConfig, interceptor, proxyMiddleware) {
    console.log(`applyProxyRoute path : ${path}`);
    app.use(path,
        (req, res, next) => { // Middleware
            console.log(`Route reached before authMiddleware : ${req.method} ${req.path}`);
            return authMiddleware(authConfig)(req, res, next);
        },
        (req, res, next) => { // requestInterceptor
            console.log(`Route reached before requestInterceptor : ${req.method} ${req.path}`);
            return interceptor.requestInterceptor(req, res, next);
        },
        (req, res, next) => { // responseInterceptor
            console.log(`Route reached before responseInterceptor : ${req.method} ${req.path}`);
            return interceptor.responseInterceptor(req, res, next);
        },
        proxyMiddleware  // Proxy route middleware*/
    );
    /*app.use(path,
        (req, res, next) => authMiddleware(authConfig)(req, res, next),  // Authorization middleware
        (req, res, next) => interceptor.requestInterceptor(req, res, next), // Request interceptor (custom logic)
        (req, res, next) => interceptor.responseInterceptor(req, res, next), // Response interceptor (custom logic)
        proxyMiddleware  // Proxy route middleware
    );*/
}

// Apply Middlewares
app.use(loggingMiddleware);
app.use(rateLimiter);

// Proxy Routes with dynamic interceptor handling
applyProxyRoute('/api/auth', authEndpoints, authInterceptor, authenticationServiceProxyMiddleware);
applyProxyRoute('/api/vconnect', vConnectEndpoints, vConnectInterceptor, vConnectEmergencyServiceProxyMiddleware);

app.use('/v1/api/auth/public-keys', (req, res, next) => {
    console.log("Request for /v1/api/auth/public-keys received");
    next();
}, createProxyMiddleware({
    target: 'http://localhost:3001',
    changeOrigin: true,
    pathRewrite: {
        '^/v1/api/auth': '', // Strip out /v1/api/auth from the URL before forwarding to the backend
    },
    onProxyReq: (proxyReq, req, res) => {
        console.log(`authenticationService --> onProxyReq`);
        console.log(`authenticationService --> Proxying request to: ${proxyReq.href}`);
    },
    onError: (err, req, res) => {
        console.log(`authenticationService --> onError`);
        console.error(`authenticationService --> Error in proxying request: ${err.message}`);
        res.status(502).json({ message: 'Bad Gateway: authentication Service is down' });
    },
    onProxyRes: (proxyRes, req, res) => {
        console.log(`authenticationService --> onProxyRes`);
        console.log(`authenticationService --> Received ${proxyRes.statusCode} from ${req.url}`);
    },
    onProxyReqWs: (proxyReq, req, socket, options, head) => {
        console.log(`authenticationService --> onProxyReqWs`);
        console.log('WebSocket request proxying...');
    }
}));

/*app.use('/api/auth', (req, res, next) => {
    console.log(`Request received for ${req.method} ${req.path}`);
    next();
}, authenticationServiceProxyMiddleware);*/
/*
// Proxy Routes
app.use('/api/auth', authMiddleware(authEndpoints), authenticationServiceProxyMiddleware);
app.use('/api/vconnect', authMiddleware(vConnectEndpoints), vConnectEmergencyServiceProxyMiddleware);

*/

// Global Error Handler
app.use(errorHandler);

// Start the API Gateway server
app.listen(PORT, () => {
    console.log(`API Gateway running on port ${PORT}`);
    gwlogger.info(`API Gateway running on port ${PORT}`);
});
