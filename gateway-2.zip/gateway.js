const express = require('express');

const {createProxyMiddleware} = require('http-proxy-middleware');

// Setup Express App
const app = express();
const PORT = process.env.PORT || 3000;

/*app.use('/v1/api/auth/public-keys', (req, res, next) => {
    console.log("Request for /v1/api/auth/public-keys received");
    next();
}, createProxyMiddleware({
    target: 'http://localhost:3001',
    changeOrigin: true,
    onProxyReq: (proxyReq, req, res) => {
        console.log(`authenticationService --> onProxyReq`);
        console.log(`authenticationService --> Proxying request to: ${proxyReq.href}`);
    },
    onError: (err, req, res) => {
        console.log(`authenticationService --> onError`);
        console.error(`authenticationService --> Error in proxying request: ${err.message}`);
        res.status(502).json({ message: 'Bad Gateway: authentication Service is down' });
    },
    onProxyRes: (proxyRes, req, res) => {
        console.log(`authenticationService --> onProxyRes`);
        console.log(`authenticationService --> Received ${proxyRes.statusCode} from ${req.url}`);
    },
    onProxyReqWs: (proxyReq, req, socket, options, head) => {
        console.log(`authenticationService --> onProxyReqWs`);
        console.log('WebSocket request proxying...');
    }
}));*/


app.use('/test-proxy', createProxyMiddleware({
    target: 'http://localhost:3001', // Make sure the target server is running on this port
    changeOrigin: true,
    pathRewrite: {
        '^/test-proxy': '/test-proxy', // No path rewrite for this example
    },
    onProxyReq: (proxyReq, req, res) => {
        console.log('Test Proxy --> onProxyReq');
        console.log('Proxying request to: ' + proxyReq.href);
    },
    onError: (err, req, res) => {
        console.log('Test Proxy --> onError');
        console.error('Error in proxying request: ' + err.message);
        res.status(502).json({ message: 'Bad Gateway: test Proxy Service is down' });
    },
    onProxyRes: (proxyRes, req, res) => {
        console.log('Test Proxy --> onProxyRes');
        console.log('Received ' + proxyRes.statusCode + ' from ' + req.url);
    }
}));

app.use((req, res) => {
    console.log(`No route matched for: ${req.method} ${req.originalUrl}`);
    res.status(404).send('Not Found');
});


// Start the API Gateway server
app.listen(PORT, () => {
    console.log(`API Gateway running on port ${PORT}`);
});
