const {authenticate} = require('@config/jweAuth');

// Authentication middleware using JWE
// Middleware to handle authorization dynamically based on the config provided
function authorizationMiddleware(serviceConfig) {
    return (req, res, next) => {

		console.log('Inside req.path ', req.path);
		console.log('Inside req.url ', req.url);
		console.log('Inside req.originalUrl ', req.originalUrl);

		// Check if the request path is in the unsecured list for the current service
        const unsecuredPath = serviceConfig.unsecuredEndpoints.find(endpoint =>
            endpoint.path === req.originalUrl && endpoint.method.includes(req.method)
        );
		console.log('Inside authorizationMiddleware unsecuredPath -> ', unsecuredPath);
        if (unsecuredPath) {
            return next();  // Skip authentication for these paths
        }

        // 1FA/2FA Secured Endpoints Validation
        const securedEndpoint = serviceConfig.securedEndpoints.find(endpoint =>
            endpoint.path === req.originalUrl && endpoint.method.includes(req.method)
        );

		console.log('Inside authorizationMiddleware securedEndpoint -> ', securedEndpoint);
        // If not found in unsecured or secured, return 404 error
        if (!unsecuredPath && !securedEndpoint) {
            return res.status(404).json({ message: 'Endpoint not found or not configured' });
        }

        // Get the token from the Authorization header
        const token = req.headers['authorization']?.split(' ')[1]; // Bearer token
        if (!token) {
            return res.status(403).json({ message: 'No token provided' });
        }

        try {
            // Authenticate the user using the token
            const user = authenticate(token);
            req.user = user;

            if (securedEndpoint) {
                if (securedEndpoint.authType === '2FA' && user.authType !== '2FA') {
                    return res.status(401).json({ message: '2FA authentication required for this endpoint' });
                }
                if (securedEndpoint.authType === '1FA' && user.authType !== '1FA' && user.authType !== '2FA') {
                    return res.status(401).json({ message: '1FA authentication required for this endpoint' });
                }
            }

            // Request Interceptor: Add custom headers after token verification
            // Add custom headers after successful authentication, with undefined checks
            if (user.username !== undefined && user.username !== null) {
                req.headers['x-authenticated-user'] = user.username;  // Add user info if defined
            }

            if (user.authType !== undefined && user.authType !== null) {
                req.headers['x-authentication-status'] = user.authType;  // Add authentication type if defined
            }
            console.log("Before Next");
            next();
        } catch (err) {
            console.log(err);
            return res.status(401).json({ message: 'Invalid or expired token' });
        }


    };
}

module.exports = authorizationMiddleware;
