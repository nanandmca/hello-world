const axios = require('axios');  // Import axios for HTTP requests

async function authenticate(token) {
    try {

        // Make a GET request to the authentication service's introspect endpoint
        const response = await axios.get('http://localhost:3001/auth/introspect', {
            headers: {
                'Authorization': `Bearer ${token}`  // Send the token in the Authorization header
            }
        });


        // Check if the response has data and return the user details
        if (response.data && response.data.username) {
            const user = {
                username: response.data.username,
                authType: response.data.authType || '1FA',  // Default to 1FA if no authType provided
                apps: response.data.apps || []  // Default to empty array if apps are not provided
            };

            // Validate if the user has access to the app based on the endpoint config
            const appAccessValid = validateAppAccess(user.apps, serviceConfig);
            if (!appAccessValid) {
                throw new Error('User does not have access to the requested app');
            }

            // Enrich headers with user information
            return {
                ...user,
                enrichedHeaders: {
                    'x-authenticated-user': user.username,
                    'x-authentication-status': user.authType
                }
            };
        } else {
            throw new Error('Invalid response from introspect API');
        }

    } catch (err) {
        console.error('Authentication error:', err.message);
        throw new Error('Invalid or expired token');
    }
}

exports.authenticate = authenticate;