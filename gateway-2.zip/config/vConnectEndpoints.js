module.exports = {
    unsecuredEndpoints: [
        { path: '/api/vconnect/healthcheck', method: ['GET'] }
    ],
    securedEndpoints: [
        { path: '/products', method: ['GET'], authType: '1FA' },
        { path: '/api/vconnect/userInfo', method: ['GET'], authType: '1FA' },
        { path: '/api/vconnect/2faSettings', method: ['POST'], authType: '2FA' }
    ]
};

