const rateLimit = require('express-rate-limit');

// Rate limit setup - Max 100 requests per 15 minutes per IP
const rateLimiter = rateLimit({
    windowMs: 15 * 60 * 1000, // 15 minutes
    max: 100, // Max 100 requests
    message: 'Too many requests, please try again later.',
});

module.exports = rateLimiter;
