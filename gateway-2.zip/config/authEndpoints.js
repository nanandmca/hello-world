module.exports = {
    unsecuredEndpoints: [
        { path: '/api/auth/public-keys', method: ['GET'] },
        { path: '/api/auth/login', method: ['POST'] },
        { path: '/api/auth/register', method: ['POST'] },
        { path: '/api/auth/forgot-password', method: ['POST'] }
    ],
    securedEndpoints: [
        { path: '/users', method: ['GET'], authType: '1FA'},
        { path: '/api/auth/userInfo', method: ['GET'], authType: '1FA' },
        { path: '/api/auth/changePassword', method: ['POST'], authType: '1FA' },
        { path: '/api/auth/verify2FA', method: ['POST'], authType: '2FA' },
        { path: '/api/auth/changeSecuritySettings', method: ['PUT'], authType: '2FA' }
    ]
};

